# gbTeXpublisher

gbTeXpublisher es una aplicación diseñada para facilitar la producción editorial de libros y revistas.

Adhiere al modelo de producción de fuente única [(_single source_)](https://en.wikipedia.org/wiki/Single-source_publishing), el mismo es un enfoque para flujos de trabajo de edición y publicación para producir diversos formatos de salida a partir de una única fuente de datos, gbTeXpublisher lo hace a través de LaTeX, pudiendo realizar salidas para PDF, HTML5, ePub, ODT y JATS.
